package org.example.ananymousClass;

interface Calculator {
    int calculate(int a, int b);
}